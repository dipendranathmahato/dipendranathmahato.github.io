# Calculus I (MATH 1210, Tulane University) — interactive course pages

Two course folders share the same lesson content:

- `courses/calculus1-summer2025/` — MATH 1210-01, Summer 2025 (online)
- `courses/calculus1-fall2024/` — MATH 1210-12, Fall 2024

Each folder contains:

- `index.html` — course home (sections by chapter, "This week" button, week-by-week order, Course Foundations dialog)
- one folder per section page, named by the OpenStax section number: `1-1/`, `2-3/`, `3-9/`, `4-10/`, `6-5/`, …
  (each has `index.html` and `lesson.js`)
- `assets/calc-core.js` (shared interactive library, `window.CA`) and `assets/calc-course.css`

The `_builder` folder is not published (Jekyll skips folders that start with an underscore).

## Rebuilding

```
cd courses/calculus1-summer2025/_builder      # or calculus1-fall2024/_builder
python3 build.py          # rebuild every page
python3 build.py 5.3      # rebuild one section page (and the home page)
```

- `course.py` — the TERM block at the top is the only part that differs between the two folders: section, term, folder name (`SLUG`), header lines, class meetings shown on the course home (`MEETINGS`), Monday of week 1 (`WEEK1`), and the week in which each section was taught (`WEEKS`). Below it: chapters, sections (id, slug, title, OpenStax slug, motivating question, card text) and the "coming from / up next" bridge text.
- `src/sections/<slug>.html` and `<slug>.js` — the content and the activities of each section page. Two macros are expanded by `build.py`:
  - `<!--GUIDED|Title|Intro-->` → the guided-problems block; the matching bank is `CA.guided('<id without dots>', [...])` in the `.js` file
  - `<!--WRAP|Title` followed by `Q:` / `A:` lines and `-->` → the "Check your understanding" block
- `src/calc-core.js`, `src/calc-course.css`, `src/foundations-dialog.html`, `src/grade-calculator.js` — copied into the published `assets/` folder or inlined on build. The foundations dialog and the grade calculator hold each term's syllabus details.

The lesson files (`src/sections/`, `src/calc-core.js`, `src/calc-course.css`) are identical in the two builders. After editing a lesson in one builder, copy the file to the other builder and rebuild both.

The shared header, sidebar, and footer come from `/assets/js/site-template.js`. When that file changes, update `SITE_TEMPLATE_VERSION` in `build.py` so browsers fetch the new copy.
